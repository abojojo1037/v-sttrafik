# JourneyId

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **string** | ID of this journey | 
**route_idx_to** | **int** | End of validity on total route | 
**route_idx_from** | **int** | Start of validity on total route | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


