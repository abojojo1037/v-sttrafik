# TimeTableData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**creation_date** | [**\Swagger\Client\Model\CreationDate**](CreationDate.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


