# Color

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bg_color** | **string** | Backgroundcolor of this line | 
**fg_color** | **string** | Foregroundcolor of this line | 
**stroke** | **string** | Stroke style of this line | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


