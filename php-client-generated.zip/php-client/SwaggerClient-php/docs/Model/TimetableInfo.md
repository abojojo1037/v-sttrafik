# TimetableInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**time_table_data** | [**\Swagger\Client\Model\TimeTableData**](TimeTableData.md) |  | 
**time_table_period** | [**\Swagger\Client\Model\TimeTablePeriod**](TimeTablePeriod.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


