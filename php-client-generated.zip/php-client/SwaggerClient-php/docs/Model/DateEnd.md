# DateEnd

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | [**\DateTime**](\DateTime.md) | End of timetable period in format YYYY-MM-DD | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


