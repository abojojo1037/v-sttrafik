# JourneyName

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**route_idx_to** | **int** | End of validity on total route. | 
**route_idx_from** | **int** | Start of validity on total route | 
**name** | **string** | Name to be displayed | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


