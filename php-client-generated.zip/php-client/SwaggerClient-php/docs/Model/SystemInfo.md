# SystemInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**timetable_info** | [**\Swagger\Client\Model\TimetableInfo**](TimetableInfo.md) |  | [optional] 
**error_text** | **string** |  | [optional] 
**error** | **string** |  | [optional] 
**serverdate** | [**\DateTime**](\DateTime.md) |  | [optional] 
**servertime** | **string** | Current server time in format HH:MM | [optional] 
**no_namespace_schema_location** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


